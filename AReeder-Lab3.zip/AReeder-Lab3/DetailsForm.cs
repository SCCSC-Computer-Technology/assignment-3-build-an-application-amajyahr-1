﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AReeder_Lab3
{
    public partial class DetailsForm : Form
    {

        private State state;
        private StateExtra stateExtra;
        public DetailsForm(State state, StateExtra stateExtra)
        {
            InitializeComponent();
            this.state = state;
            this.stateExtra = stateExtra;

            txtState.Text = state.StateName;
            txtPopulation.Text = state.Population.ToString();
            txtIncome.Text = state.MedianIncome.ToString("C");
            txtBird.Text = state.StateBird;
            txtFlower.Text = state.StateFlower;
            txtCapital.Text = state.StateCapital;
            txtColors.Text = state.StateColors;
            txtJobs.Text = state.ComputerJobPercentage.ToString("P");
            txtCities.Text = state.LargestCities;
            txtFlag.Text = state.StateFlag;


        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // Update the state object with the new values from the textboxes
                state.StateName = txtState.Text;
                state.Population = Convert.ToDecimal(txtPopulation.Text);
                state.StateBird = txtBird.Text;
                state.StateFlower = txtFlower.Text;
                state.StateCapital = txtCapital.Text;
                state.StateColors = txtColors.Text;
                state.ComputerJobPercentage = Convert.ToInt32(txtJobs.Text);
                state.LargestCities = txtCities.Text;
                state.StateFlag = txtFlag.Text;
                state.MedianIncome = Convert.ToInt32(txtIncome.Text);

                // Call the method to update the state in the database
                stateExtra.UpdateState(state);

                MessageBox.Show("State updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating state: {ex.Message}");
            }


            
        }

    }
}
