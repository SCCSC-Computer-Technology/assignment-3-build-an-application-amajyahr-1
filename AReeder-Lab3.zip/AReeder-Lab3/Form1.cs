﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace AReeder_Lab3
{
    public partial class States : Form
    {
        private string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Amajyah\OneDrive\Desktop\C# Practice\Chapter 13 Practice\AReeder-Lab3\UnitedStates.mdf"";Integrated Security=True";
        private List<State> states;
        private StateExtra stateExtra;
        public States()
        {
            InitializeComponent();
            stateExtra = new StateExtra(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Amajyah\OneDrive\Desktop\C# Practice\Chapter 13 Practice\AReeder-Lab3\UnitedStates.mdf"";Integrated Security=True");
            LoadStates();
            PopulateCmbStates();
        }

        private void PopulateCmbStates()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                try
                {
                    //open connection
                    connection.Open();

                    string query = "SELECT StateID, StateName FROM States";
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataSet dataSet = new DataSet();
                    dataAdapter.Fill(dataSet);

                    cmbStates.DataSource = dataSet.Tables[0];
                    cmbStates.DisplayMember = "StateName";
                    cmbStates.ValueMember = "StateID";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        private void LoadStates()
        {
            try
            {
                states = stateExtra.GetAllStates();

                if (states == null || !states.Any())
                {
                    MessageBox.Show("No states found in the database.");
                    return;
                }

                // Bind to DataGridView
                statesDataGridView.AutoGenerateColumns = true; // Ensure columns are generated
                statesDataGridView.DataSource = states.Select(s => new
                {
                    s.StateName,
                    s.Population,
                    s.StateCapital,
                    s.MedianIncome,
                    s.ComputerJobPercentage,
                    s.StateBird,
                    s.StateFlower,
                    s.StateID,
                    s.StateFlag,
                    s.StateColors,
                    s.LargestCities

                }).ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading states: {ex.Message}");

            }
        }

        private void statesBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.statesBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.statesDataSet);

        }

        private void States_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'statesDataSet.States' table. You can move, or remove it, as needed.
            this.statesTableAdapter.Fill(this.statesDataSet.States);

        }

        private void btnDetails_Click(object sender, EventArgs e)
        {
            var selectedStateID = (int)cmbStates.SelectedValue;
            var selectedState = states.FirstOrDefault(s => s.StateID == selectedStateID);

            if (selectedState != null)
            {
                var detailsForm = new DetailsForm(selectedState, stateExtra);
                detailsForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("State details not found. Please try again.");
            }
        }
    }
}
