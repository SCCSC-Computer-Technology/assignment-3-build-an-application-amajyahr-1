﻿namespace AReeder_Lab3
{
    partial class DetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtPopulation = new System.Windows.Forms.TextBox();
            this.txtFlower = new System.Windows.Forms.TextBox();
            this.txtBird = new System.Windows.Forms.TextBox();
            this.txtCapital = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtIncome = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtColors = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtFlag = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtJobs = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCities = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Mongolian Baiti", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(208, 19);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(211, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "State Details";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(66, 352);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(158, 61);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(428, 352);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(158, 61);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "State Name: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Population: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "State Flower: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "State Bird: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-3, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "State Capital: ";
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(124, 79);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(170, 29);
            this.txtState.TabIndex = 8;
            this.txtState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPopulation
            // 
            this.txtPopulation.Location = new System.Drawing.Point(124, 115);
            this.txtPopulation.Name = "txtPopulation";
            this.txtPopulation.Size = new System.Drawing.Size(170, 29);
            this.txtPopulation.TabIndex = 9;
            this.txtPopulation.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFlower
            // 
            this.txtFlower.Location = new System.Drawing.Point(124, 150);
            this.txtFlower.Name = "txtFlower";
            this.txtFlower.Size = new System.Drawing.Size(170, 29);
            this.txtFlower.TabIndex = 10;
            this.txtFlower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBird
            // 
            this.txtBird.Location = new System.Drawing.Point(124, 187);
            this.txtBird.Name = "txtBird";
            this.txtBird.Size = new System.Drawing.Size(170, 29);
            this.txtBird.TabIndex = 11;
            this.txtBird.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCapital
            // 
            this.txtCapital.Location = new System.Drawing.Point(124, 222);
            this.txtCapital.Name = "txtCapital";
            this.txtCapital.Size = new System.Drawing.Size(170, 29);
            this.txtCapital.TabIndex = 12;
            this.txtCapital.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(316, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(148, 20);
            this.label6.TabIndex = 13;
            this.label6.Text = "Median Income:";
            // 
            // txtIncome
            // 
            this.txtIncome.Location = new System.Drawing.Point(478, 73);
            this.txtIncome.Name = "txtIncome";
            this.txtIncome.Size = new System.Drawing.Size(170, 29);
            this.txtIncome.TabIndex = 14;
            this.txtIncome.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(338, 118);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "State Colors: ";
            // 
            // txtColors
            // 
            this.txtColors.Location = new System.Drawing.Point(478, 109);
            this.txtColors.Multiline = true;
            this.txtColors.Name = "txtColors";
            this.txtColors.Size = new System.Drawing.Size(170, 64);
            this.txtColors.TabIndex = 16;
            this.txtColors.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 254);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "State Flag: ";
            // 
            // txtFlag
            // 
            this.txtFlag.Location = new System.Drawing.Point(124, 257);
            this.txtFlag.Multiline = true;
            this.txtFlag.Name = "txtFlag";
            this.txtFlag.Size = new System.Drawing.Size(170, 81);
            this.txtFlag.TabIndex = 18;
            this.txtFlag.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(297, 190);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(175, 20);
            this.label9.TabIndex = 19;
            this.label9.Text = "Computer Jobs(%):";
            // 
            // txtJobs
            // 
            this.txtJobs.Location = new System.Drawing.Point(478, 187);
            this.txtJobs.Name = "txtJobs";
            this.txtJobs.Size = new System.Drawing.Size(170, 29);
            this.txtJobs.TabIndex = 20;
            this.txtJobs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(338, 243);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 20);
            this.label10.TabIndex = 21;
            this.label10.Text = "Largest Cities:";
            // 
            // txtCities
            // 
            this.txtCities.Location = new System.Drawing.Point(478, 240);
            this.txtCities.Multiline = true;
            this.txtCities.Name = "txtCities";
            this.txtCities.Size = new System.Drawing.Size(170, 98);
            this.txtCities.TabIndex = 22;
            this.txtCities.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(660, 425);
            this.Controls.Add(this.txtCities);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtJobs);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtFlag);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtColors);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtIncome);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCapital);
            this.Controls.Add(this.txtBird);
            this.Controls.Add(this.txtFlower);
            this.Controls.Add(this.txtPopulation);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "DetailsForm";
            this.Text = "DetailsForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtPopulation;
        private System.Windows.Forms.TextBox txtFlower;
        private System.Windows.Forms.TextBox txtBird;
        private System.Windows.Forms.TextBox txtCapital;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtIncome;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtColors;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtFlag;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtJobs;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCities;
    }
}